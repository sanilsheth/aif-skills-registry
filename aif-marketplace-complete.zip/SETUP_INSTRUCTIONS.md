# Public Repo Setup Instructions

For: `sanilsheth/aif-skills-registry`

## Step 1: Extract Files
Extract `aif-marketplace-complete.zip` to the public repo root:
```
site/           → Keep all marketplace.json files
dist/           → All vendor-specific skills
```

## Step 2: Add GitHub Pages Workflow
1. Create `.github/workflows/` directory in public repo (if not exists)
2. Copy `PUBLIC_REPO_pages.yml` to `.github/workflows/pages.yml`
3. Commit and push

## Step 3: Enable GitHub Pages
In public repo settings:
1. Go to **Settings** → **Pages**
2. Set **Source** to "GitHub Actions"
3. The workflow will auto-deploy on next push

## Step 4: Verify Deployment
After pushing, check:
- Workflow runs: https://github.com/sanilsheth/aif-skills-registry/actions
- GitHub Pages: https://github.com/sanilsheth/aif-skills-registry/settings/pages

## Installation URLs (for Users)

### Copilot Users:
```bash
bash -c "$(curl -sSL https://sanilsheth.github.io/aif-skills-registry/dist/copilot/marketplace/skill.atomic.hello-world/hooks/install.sh)"
```

### Claude Code Users:
```bash
mkdir -p ~/.claude/skills/skill.atomic.hello-world && curl -sSL https://sanilsheth.github.io/aif-skills-registry/dist/claude/.claude/skills/skill.atomic.hello-world/SKILL.md -o ~/.claude/skills/skill.atomic.hello-world/SKILL.md
```

### OpenCode Users:
```bash
mkdir -p ~/.opencode/skills/skill.atomic.hello-world && curl -sSL https://sanilsheth.github.io/aif-skills-registry/dist/opencode/.opencode/skills/skill.atomic.hello-world/SKILL.md -o ~/.opencode/skills/skill.atomic.hello-world/SKILL.md
```

## Marketplace Discovery

Users can also browse available skills at:
- https://sanilsheth.github.io/aif-skills-registry/site/marketplace.json (canonical)
- https://sanilsheth.github.io/aif-skills-registry/site/copilot-marketplace.json
- https://sanilsheth.github.io/aif-skills-registry/site/claude-marketplace.json
- https://sanilsheth.github.io/aif-skills-registry/site/opencode-marketplace.json
