# Documentation Index

## Project Design

- [Design Intent](design-intent.md) — project goals, concepts, and architecture
- [Design Decisions](decisions/) — ADR and decision records
- [Design Rationale](design/) — technical deep dives

## Vendor Research

- [Vendors Overview](vendors/README.md) — quick reference table
- [Copilot](vendors/copilot.md)
- [Claude Code](vendors/claude.md)
- [OpenCode](vendors/opencode.md)
- [Cursor](vendors/cursor.md)
- [Codex](vendors/codex.md)
- [Windsurf](vendors/windsurf.md)
- [Devin](vendors/devin.md)

## Getting Started

- Start with [../AGENTS.md](../AGENTS.md) to understand the core principles
- Then read [../README.md](../README.md) for the three-step process
- For development, see [../CONTRIBUTING.md](../CONTRIBUTING.md)

## API and Schema

- Canonical schema (coming soon)
- Vendor capability data format
- Adapter transformation rules
